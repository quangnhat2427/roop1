#!/usr/bin/env python3

from facefusion import installer

if __name__ == '__main__':
	installer.cli()
